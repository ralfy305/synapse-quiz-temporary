export enum AppZone {
  ONBOARDING = 'ONBOARDING',
  DASHBOARD = 'DASHBOARD',
  AIRLOCK = 'AIRLOCK',
  CHAT = 'CHAT'
}

export enum QuizCategory {
  BOUNDARIES = 'The Boundary Scale',
  INTIMACY = 'The Intimacy Spectrum',
  TRIGGERS = 'Core Conflict Triggers'
}

export interface QuizQuestion {
  id: string;
  category: QuizCategory;
  text: string;
  options?: string[];
  type: 'scale' | 'choice' | 'text'; // scale: agree/disagree, choice: multiple choice
}

export interface QuizAnswers {
  [questionId: string]: string;
}

export interface PonzAnalysis {
  emotional_summary: string;
  relationship_insight: string;
  suggested_response: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'partner' | 'ponz';
  text: string;
  timestamp: Date;
  analysis?: PonzAnalysis; // Only present if Ponz analyzed a draft
  isDraft?: boolean; // If true, it's currently in the "Airlock" or "Interception" phase
}

export interface AirlockState {
  fact: string;
  feelings: string[];
  needs: string[];
  openingStatement?: string;
}

import React, { useState, useRef, useEffect } from 'react';
import { AirlockState, ChatMessage, PonzAnalysis } from '../types';
import { analyzeMessage } from '../services/geminiService';

interface ChatInterfaceProps {
  initialState: AirlockState;
  onExit: () => void;
}

const STORAGE_KEY = 'synapse_chat_history';

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ initialState, onExit }) => {
  // Initialize state from localStorage if available
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved, (key, value) => {
          // Restore Date objects from strings
          if (key === 'timestamp') return new Date(value);
          return value;
        });
        
        // Safety check: ensure the parsed data is actually an array
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (e) {
      console.error("Failed to load chat history:", e);
    }
    return [];
  });

  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [activeUser, setActiveUser] = useState<'user' | 'partner'>('user');
  const scrollRef = useRef<HTMLDivElement>(null);

  // Initialize Chat with Dr. Ponz's Opening ONLY if history is empty
  useEffect(() => {
    if (messages.length === 0 && initialState.openingStatement) {
      setMessages([{
        id: 'init',
        sender: 'ponz',
        text: `Welcome, Ralfy and Will. Ralfy has initiated this session. ${initialState.openingStatement} I'm here to help you both explore this safely.`,
        timestamp: new Date()
      }]);
    }
    // Dependency on initialState ensures this runs when entering from Airlock,
    // checking messages.length prevents overwriting existing history.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialState]);

  // Auto-save messages to localStorage whenever they change
  useEffect(() => {
    try {
      if (messages.length > 0) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
      }
    } catch (e) {
      console.warn("Failed to save chat history:", e);
    }
  }, [messages]);

  // Scroll to bottom on new message
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const msgSender = activeUser;
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: msgSender,
      text: inputText,
      timestamp: new Date(),
      isDraft: true
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsProcessing(true);

    // Dr. Ponz Analysis
    const analysis: PonzAnalysis = await analyzeMessage(userMsg.text, `
      Context: Relationship conflict discussion.
      Speaker: ${msgSender === 'user' ? 'Ralfy' : 'Will'}.
      Previous Fact: ${initialState.fact}
      Needs: ${initialState.needs.join(', ')}
    `);

    setIsProcessing(false);

    // Replace draft with Ponz's intervention or approval
    setMessages(prev => {
      const filtered = prev.filter(m => m.id !== userMsg.id);
      
      return [...filtered, {
        id: Date.now().toString() + '_ponz',
        sender: 'ponz',
        text: analysis.suggested_response, 
        timestamp: new Date(),
        analysis: analysis
      }];
    });
  };

  const handleExit = () => {
    // Explicitly save before exit (redundant with auto-save but requested for safety)
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
    } catch (e) {
      console.warn("Failed to save on exit:", e);
    }
    onExit();
  };

  const handlePause = () => {
    setIsPaused(true);
  };

  if (isPaused) {
    return (
      <div className="fixed inset-0 z-50 bg-synapse-bg/95 flex flex-col items-center justify-center p-6 animate-fade-in">
        <h2 className="text-4xl font-bold text-synapse-text mb-4">Session Paused</h2>
        <p className="text-xl text-synapse-muted max-w-md text-center mb-12">
          A pause has been requested. Take a breath. Get some water. The conversation will resume when you are ready.
        </p>
        <div className="w-24 h-24 rounded-full border-4 border-synapse-blue/30 flex items-center justify-center mb-8">
          <span className="text-2xl font-mono text-synapse-blue">5:00</span>
        </div>
        <button 
          onClick={() => setIsPaused(false)}
          className="px-8 py-3 bg-synapse-border hover:bg-synapse-card text-synapse-text rounded-lg border border-synapse-border transition-all"
        >
          I'm Ready to Resume
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] max-w-4xl mx-auto bg-synapse-bg">
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-synapse-border bg-synapse-bg/80 backdrop-blur sticky top-0 z-10">
        <div>
          <h2 className="font-bold text-synapse-text">Dr. Ponz Session</h2>
          <span className="text-xs text-synapse-green">● Moderated</span>
        </div>
        <div className="flex gap-2">
            <button 
                onClick={handleExit}
                className="px-4 py-2 text-xs font-bold text-synapse-muted hover:text-synapse-text transition-all uppercase tracking-widest"
            >
                Exit
            </button>
            <button 
              onClick={handlePause}
              className="px-4 py-2 text-xs font-bold text-red-400 border border-red-900/30 bg-red-900/10 rounded hover:bg-red-900/20 transition-all uppercase tracking-widest"
            >
              Pause Session
            </button>
        </div>
      </div>

      {/* Chat Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : msg.sender === 'partner' ? 'items-start' : 'items-center'} animate-fade-in`}
          >
            {/* Ponz Analysis Bubble */}
            {msg.sender === 'ponz' && msg.analysis && (
              <div className="w-full max-w-2xl bg-synapse-card/80 border border-synapse-green/30 rounded-lg p-4 mb-2 text-sm">
                <div className="flex items-center gap-2 mb-2 text-synapse-green font-bold text-xs uppercase tracking-wider">
                  <span>🧠 Dr. Ponz Insight</span>
                </div>
                <div className="grid md:grid-cols-2 gap-4 mb-3">
                  <div>
                    <span className="text-xs text-synapse-muted block mb-1">Emotional Summary</span>
                    <p className="text-synapse-text">{msg.analysis.emotional_summary}</p>
                  </div>
                  <div>
                    <span className="text-xs text-synapse-muted block mb-1">Relationship Insight</span>
                    <p className="text-synapse-text">{msg.analysis.relationship_insight}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Message Bubble */}
            <div 
              className={`max-w-[80%] p-4 shadow-lg ${
                msg.isDraft 
                  ? 'bg-synapse-border opacity-50 italic rounded-2xl'
                  : msg.sender === 'ponz'
                    ? 'bg-synapse-card border-t-2 border-synapse-green text-synapse-text text-center w-full max-w-2xl rounded-lg'
                    : msg.sender === 'user'
                      ? 'bg-gradient-to-br from-synapse-card to-synapse-red/15 border border-synapse-red/30 text-synapse-text rounded-2xl rounded-tr-md'
                      : 'bg-gradient-to-br from-synapse-card to-synapse-blue/15 border border-synapse-blue/30 text-synapse-text rounded-2xl rounded-tl-md'
              }`}
            >
              {msg.text}
            </div>
            
            {msg.sender === 'ponz' && (
              <div className="text-[10px] text-synapse-muted mt-1 uppercase tracking-widest">System Reframe</div>
            )}
          </div>
        ))}
        
        {isProcessing && (
          <div className="flex justify-center items-center py-8">
            <div className="flex space-x-2">
              <div className="w-2 h-2 bg-synapse-green rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-synapse-green rounded-full animate-bounce delay-100"></div>
              <div className="w-2 h-2 bg-synapse-green rounded-full animate-bounce delay-200"></div>
            </div>
            <span className="ml-3 text-xs text-synapse-green uppercase tracking-widest">Dr. Ponz is analyzing...</span>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-synapse-border bg-synapse-bg">
        {/* Toggle Switch for User/Partner */}
        <div className="flex justify-center mb-3">
            <div className="bg-synapse-card border border-synapse-border rounded-full p-1 flex gap-1">
                <button
                    onClick={() => setActiveUser('user')}
                    className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${activeUser === 'user' ? 'bg-synapse-red text-white shadow-lg shadow-synapse-red/20' : 'text-synapse-muted hover:text-synapse-text'}`}
                >
                    Ralfy (User)
                </button>
                <button
                    onClick={() => setActiveUser('partner')}
                    className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${activeUser === 'partner' ? 'bg-synapse-blue text-white shadow-lg shadow-synapse-blue/20' : 'text-synapse-muted hover:text-synapse-text'}`}
                >
                    Will (Partner)
                </button>
            </div>
        </div>

        <div className="flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={activeUser === 'user' ? "Type message as Ralfy (User)..." : "Type message as Will (Partner)..."}
            className={`flex-1 bg-synapse-card border border-synapse-border rounded-lg px-4 py-3 text-synapse-text outline-none transition-all ${activeUser === 'user' ? 'focus:border-synapse-red focus:ring-1 focus:ring-synapse-red' : 'focus:border-synapse-blue focus:ring-1 focus:ring-synapse-blue'}`}
          />
          <button 
            onClick={handleSendMessage}
            disabled={!inputText.trim() || isProcessing}
            className={`px-6 text-white font-bold rounded-lg disabled:opacity-50 transition-all ${activeUser === 'user' ? 'bg-synapse-red hover:bg-synapse-red/90' : 'bg-synapse-blue hover:bg-synapse-blue/90'}`}
          >
            Send
          </button>
        </div>
        <p className="text-center text-[10px] text-synapse-muted mt-2">
          Your messages are intercepted and reframed for safety.
        </p>
      </div>
    </div>
  );
};

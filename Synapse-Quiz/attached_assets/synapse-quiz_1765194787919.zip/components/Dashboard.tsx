import React from 'react';
import { QuizAnswers } from '../types';

interface DashboardProps {
  answers: QuizAnswers;
  onEnterAirlock: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ answers, onEnterAirlock }) => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-synapse-text">Welcome, Ralfy & Will</h1>
          <p className="text-synapse-muted">Relationship Status: Synced</p>
        </div>
        <div className="group relative">
          <span className="text-2xl cursor-help">🛡️</span>
          <div className="absolute right-0 top-full mt-2 w-48 bg-synapse-card border border-synapse-border p-3 rounded text-xs text-synapse-muted hidden group-hover:block z-10 shadow-xl">
            Our Ethical Promise: Privacy, Neutrality, Non-Coercion.
          </div>
        </div>
      </div>

      {/* Synapse Graphic Area */}
      <div className="relative h-80 bg-synapse-card border border-synapse-border rounded-2xl mb-8 overflow-hidden flex items-center justify-center">
        {/* Abstract Background */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-synapse-bg to-transparent opacity-50"></div>
        
        {/* Connection Lines (CSS Art) */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          {/* Main Synapse Connection */}
          <path 
            d="M 200 160 Q 450 60 700 160" 
            stroke="#69db7c" 
            strokeWidth="3" 
            fill="none"
            filter="url(#glow)"
            className="animate-pulse-slow"
          />
          {/* Frayed Line */}
          <path 
            d="M 200 160 Q 450 260 700 160" 
            stroke="#ff6b6b" 
            strokeWidth="1" 
            fill="none"
            strokeDasharray="5,5"
            className="opacity-60"
          />
        </svg>

        {/* Orbs */}
        <div className="absolute left-20 lg:left-40 top-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-synapse-red shadow-[0_0_30px_rgba(255,107,107,0.5)] animate-glow flex items-center justify-center text-synapse-bg font-bold">R</div>
        <div className="absolute right-20 lg:right-40 top-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-synapse-blue shadow-[0_0_30px_rgba(77,171,247,0.5)] animate-glow flex items-center justify-center text-synapse-bg font-bold">W</div>
      </div>

      {/* Key Insights */}
      <div className="grid md:grid-cols-2 gap-6 mb-12">
        <div className="bg-synapse-card/50 p-6 rounded-xl border border-synapse-border">
          <h3 className="flex items-center text-synapse-green font-bold mb-4">
            <span className="mr-2">✅</span> Shared Strengths
          </h3>
          <ul className="space-y-3 text-sm text-synapse-text">
            <li className="flex items-start">
              <span className="w-1.5 h-1.5 rounded-full bg-synapse-green mt-2 mr-2"></span>
              You both connect deeply through Experiential Intimacy.
            </li>
            <li className="flex items-start">
              <span className="w-1.5 h-1.5 rounded-full bg-synapse-green mt-2 mr-2"></span>
              Similar boundaries around Digital Privacy.
            </li>
          </ul>
        </div>

        <div className="bg-synapse-card/50 p-6 rounded-xl border border-synapse-border">
          <h3 className="flex items-center text-yellow-500 font-bold mb-4">
            <span className="mr-2">🧭</span> Areas for Growth
          </h3>
          <ul className="space-y-3 text-sm text-synapse-text">
            <li className="flex items-start">
              <span className="w-1.5 h-1.5 rounded-full bg-yellow-500 mt-2 mr-2"></span>
              Different approaches to Conflict Triggers.
            </li>
            <li className="flex items-start">
              <span className="w-1.5 h-1.5 rounded-full bg-yellow-500 mt-2 mr-2"></span>
              Differing needs for space vs. resolution.
            </li>
          </ul>
        </div>
      </div>

      {/* Action Button */}
      <div className="text-center mb-16">
        <button 
          onClick={onEnterAirlock}
          className="group relative inline-flex flex-col items-center justify-center px-12 py-6 bg-transparent border-2 border-synapse-green text-synapse-green rounded-2xl hover:bg-synapse-green hover:text-synapse-bg transition-all duration-300 transform hover:scale-105"
        >
          <span className="text-2xl font-bold tracking-wider mb-1">[ ENTER THE AIRLOCK ]</span>
          <span className="text-sm opacity-80 group-hover:opacity-100">Start a new, moderated conversation</span>
        </button>
      </div>

      {/* Footer History */}
      <div className="border-t border-synapse-border pt-8">
        <h4 className="text-synapse-muted text-sm uppercase tracking-wider mb-4">Recent Sessions</h4>
        <div className="space-y-2">
          {['Oct 30 - Finances', 'Oct 27 - Household', 'Oct 22 - In-Laws'].map((session) => (
            <div key={session} className="flex justify-between items-center p-3 hover:bg-synapse-border/30 rounded cursor-pointer transition">
              <span className="text-synapse-text">{session}</span>
              <span className="text-xs text-synapse-blue">View Summary →</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

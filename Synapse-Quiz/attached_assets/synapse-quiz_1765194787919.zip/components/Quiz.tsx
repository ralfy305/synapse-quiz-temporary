import React, { useState } from 'react';
import { QuizQuestion, QuizCategory, QuizAnswers } from '../types';
import { QUIZ_QUESTIONS } from '../constants';

interface QuizProps {
  onComplete: (answers: QuizAnswers) => void;
}

export const Quiz: React.FC<QuizProps> = ({ onComplete }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<QuizAnswers>({});

  const question = QUIZ_QUESTIONS[currentIdx];
  const progress = ((currentIdx + 1) / QUIZ_QUESTIONS.length) * 100;

  const handleAnswer = (answer: string) => {
    const newAnswers = { ...answers, [question.id]: answer };
    setAnswers(newAnswers);
    
    if (currentIdx < QUIZ_QUESTIONS.length - 1) {
      setCurrentIdx(prev => prev + 1);
    } else {
      onComplete(newAnswers);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-synapse-text mb-2">Synapse Quiz</h2>
        <div className="w-full bg-synapse-border h-2 rounded-full overflow-hidden">
          <div 
            className="h-full bg-synapse-blue transition-all duration-500 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-synapse-muted text-sm mt-2">
          Part {Math.ceil((currentIdx + 1) / 4)}: {question.category}
        </p>
      </div>

      <div className="bg-synapse-card border border-synapse-border rounded-xl p-8 shadow-lg min-h-[400px] flex flex-col justify-center animate-fade-in">
        <h3 className="text-xl text-synapse-text mb-8 leading-relaxed">
          {question.text}
        </h3>

        <div className="space-y-4">
          {question.type === 'scale' ? (
            <div className="flex gap-4">
              {question.options?.map((opt) => (
                <button
                  key={opt}
                  onClick={() => handleAnswer(opt)}
                  className="flex-1 py-4 px-6 rounded-lg border border-synapse-border hover:border-synapse-blue hover:bg-synapse-blue/10 transition-all text-lg font-medium"
                >
                  {opt}
                </button>
              ))}
            </div>
          ) : (
            <div className="grid gap-3">
              {question.options?.map((opt) => (
                <button
                  key={opt}
                  onClick={() => handleAnswer(opt)}
                  className="text-left py-4 px-6 rounded-lg border border-synapse-border hover:border-synapse-blue hover:bg-synapse-blue/10 transition-all"
                >
                  {opt}
                </button>
              ))}
            </div>
          )}
        </div>
        
        <div className="mt-8 text-center">
          <button 
            onClick={() => handleAnswer("Skipped")}
            className="text-synapse-muted hover:text-synapse-text text-sm underline decoration-dotted"
          >
            Skip this question
          </button>
        </div>
      </div>
    </div>
  );
};

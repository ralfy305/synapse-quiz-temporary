import React, { useState, useEffect } from 'react';
import { AirlockState } from '../types';
import { FEELING_OPTIONS, NEED_OPTIONS } from '../constants';
import { analyzeMessage } from '../services/geminiService';

interface AirlockProps {
  onComplete: (state: AirlockState) => void;
}

export const Airlock: React.FC<AirlockProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);
  const [breathePhase, setBreathePhase] = useState<'in' | 'hold' | 'out'>('in');
  const [state, setState] = useState<AirlockState>({
    fact: '',
    feelings: [],
    needs: []
  });
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Breathing Animation Loop
  useEffect(() => {
    if (step !== 0) return;
    const cycle = async () => {
      setBreathePhase('in');
      await new Promise(r => setTimeout(r, 4000));
      setBreathePhase('hold');
      await new Promise(r => setTimeout(r, 4000));
      setBreathePhase('out');
      await new Promise(r => setTimeout(r, 4000));
      cycle();
    };
    cycle();
  }, [step]);

  const toggleSelection = (list: string[], item: string, setter: (l: string[]) => void) => {
    if (list.includes(item)) {
      setter(list.filter(i => i !== item));
    } else {
      if (list.length < 3) setter([...list, item]);
    }
  };

  const handleAnalysis = async () => {
    setIsAnalyzing(true);
    const context = `
      Fact: ${state.fact}
      Feelings: ${state.feelings.join(', ')}
      Needs: ${state.needs.join(', ')}
    `;
    const analysis = await analyzeMessage("Help me frame an opening statement for my partner based on these facts, feelings, and needs.", context);
    setState(prev => ({ ...prev, openingStatement: analysis.suggested_response }));
    setIsAnalyzing(false);
    setStep(4);
  };

  // Step 0: Breathe
  if (step === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-synapse-text mb-2">Welcome, Ralfy. Take a breath.</h2>
          <p className="text-synapse-muted max-w-md mx-auto">This is a private space to gather your thoughts. Your partner will not be notified until you are ready.</p>
        </div>
        
        <div className="relative flex items-center justify-center w-64 h-64 mb-12">
          <div className={`absolute inset-0 border-4 border-synapse-green/30 rounded-full transition-all duration-[4000ms] ${breathePhase === 'in' ? 'scale-100 opacity-100' : 'scale-50 opacity-50'}`} />
          <div className={`absolute inset-0 bg-synapse-green/10 rounded-full transition-all duration-[4000ms] ${breathePhase === 'in' ? 'scale-100' : 'scale-0'}`} />
          <div className="text-2xl font-light text-synapse-green">
            {breathePhase === 'in' && "Breathe In..."}
            {breathePhase === 'hold' && "Hold..."}
            {breathePhase === 'out' && "Breathe Out..."}
          </div>
        </div>

        <button 
          onClick={() => setStep(1)}
          className="px-8 py-3 bg-synapse-border hover:bg-synapse-card text-synapse-text rounded-full transition-all"
        >
          I'm ready
        </button>
      </div>
    );
  }

  // Step 1: Fact
  if (step === 1) {
    return (
      <div className="max-w-2xl mx-auto animate-fade-in p-6">
        <h2 className="text-2xl font-bold mb-2">Step 1: What happened?</h2>
        <p className="text-synapse-muted mb-6">Describe the event neutrally. Just the facts.</p>
        <textarea
          value={state.fact}
          onChange={(e) => setState({ ...state, fact: e.target.value })}
          className="w-full h-40 bg-synapse-card border border-synapse-border rounded-lg p-4 text-synapse-text focus:border-synapse-green outline-none resize-none"
          placeholder='e.g., "I saw a $500 charge for a gaming system I wasn`t aware of."'
        />
        <div className="mt-6 flex justify-end">
          <button 
            disabled={!state.fact}
            onClick={() => setStep(2)}
            className="px-6 py-2 bg-synapse-green text-synapse-bg font-bold rounded hover:opacity-90 disabled:opacity-50"
          >
            Next
          </button>
        </div>
      </div>
    );
  }

  // Step 2: Feelings
  if (step === 2) {
    return (
      <div className="max-w-2xl mx-auto animate-fade-in p-6">
        <h2 className="text-2xl font-bold mb-2">Step 2: How does this make you feel?</h2>
        <p className="text-synapse-muted mb-6">Select up to 3 primary emotions.</p>
        <div className="flex flex-wrap gap-3">
          {FEELING_OPTIONS.map(feeling => (
            <button
              key={feeling}
              onClick={() => toggleSelection(state.feelings, feeling, (f) => setState({...state, feelings: f}))}
              className={`px-4 py-2 rounded-full border transition-all ${state.feelings.includes(feeling) ? 'bg-synapse-green/20 border-synapse-green text-synapse-green' : 'border-synapse-border text-synapse-muted hover:border-synapse-text'}`}
            >
              {feeling}
            </button>
          ))}
        </div>
        <div className="mt-8 flex justify-between">
          <button onClick={() => setStep(1)} className="text-synapse-muted">Back</button>
          <button 
            disabled={state.feelings.length === 0}
            onClick={() => setStep(3)}
            className="px-6 py-2 bg-synapse-green text-synapse-bg font-bold rounded hover:opacity-90 disabled:opacity-50"
          >
            Next
          </button>
        </div>
      </div>
    );
  }

  // Step 3: Needs
  if (step === 3) {
    return (
      <div className="max-w-2xl mx-auto animate-fade-in p-6">
        <h2 className="text-2xl font-bold mb-2">Step 3: What do you need?</h2>
        <p className="text-synapse-muted mb-6">Identify the core need that feels unmet.</p>
        <div className="flex flex-wrap gap-3">
          {NEED_OPTIONS.map(need => (
            <button
              key={need}
              onClick={() => toggleSelection(state.needs, need, (n) => setState({...state, needs: n}))}
              className={`px-4 py-2 rounded-full border transition-all ${state.needs.includes(need) ? 'bg-synapse-blue/20 border-synapse-blue text-synapse-blue' : 'border-synapse-border text-synapse-muted hover:border-synapse-text'}`}
            >
              {need}
            </button>
          ))}
        </div>
        <div className="mt-8 flex justify-between">
          <button onClick={() => setStep(2)} className="text-synapse-muted">Back</button>
          <button 
            disabled={state.needs.length === 0}
            onClick={handleAnalysis}
            className="px-6 py-2 bg-synapse-green text-synapse-bg font-bold rounded hover:opacity-90 disabled:opacity-50"
          >
            {isAnalyzing ? "Sealing Airlock..." : "Review & Seal"}
          </button>
        </div>
      </div>
    );
  }

  // Step 4: Confirmation
  return (
    <div className="max-w-2xl mx-auto animate-fade-in p-6">
      <div className="text-center mb-8">
        <div className="inline-block p-4 rounded-full bg-synapse-green/10 mb-4">
          <span className="text-3xl">🔒</span>
        </div>
        <h2 className="text-2xl font-bold text-synapse-text">Your Airlock is Sealed.</h2>
        <p className="text-synapse-muted">Dr. Ponz has framed the conversation start based on your input.</p>
      </div>

      <div className="bg-synapse-card border border-synapse-border rounded-xl p-6 mb-8 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-1 h-full bg-synapse-green"></div>
        <h4 className="text-xs uppercase tracking-wider text-synapse-green mb-2">Proposed Opening Statement</h4>
        <p className="text-lg italic text-synapse-text leading-relaxed">
          "{state.openingStatement}"
        </p>
      </div>

      <div className="flex flex-col gap-4 items-center">
        <button 
          onClick={() => onComplete(state)}
          className="w-full md:w-auto px-8 py-3 bg-synapse-blue text-white font-bold rounded-lg hover:bg-synapse-blue/90 shadow-lg shadow-synapse-blue/20 transition-all"
        >
          Looks good. Send Invitation to Will
        </button>
        <button onClick={() => setStep(1)} className="text-synapse-muted hover:text-synapse-text text-sm">
          Start Over
        </button>
      </div>
    </div>
  );
};

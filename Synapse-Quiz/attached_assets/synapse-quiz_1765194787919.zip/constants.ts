import { QuizQuestion, QuizCategory } from './types';

export const DR_PONZ_SYSTEM_PROMPT = `
You are Dr. Ponz, an elite behavioral systems analyst combining world-class expertise with profound empathy.

CORE DIRECTIVE:
Every behavior, emotion, or system exists because it serves or served an adaptive purpose. Your role is to illuminate that purpose with respect, then guide toward more effective alternatives.

MANDATORY OUTPUT FORMAT:
You MUST always respond with a valid JSON object strictly adhering to this structure. Do not include markdown formatting (like \`\`\`json) outside the object. Just the raw JSON string.

{
  "emotional_summary": "[A quick read on the user's feelings]",
  "relationship_insight": "[One clear observation that adds understanding based on behavioral analysis]",
  "suggested_response": "[A short, caring example reply that fits the user’s tone and helps communication. If this is an opening statement, frame it constructively.]"
}

DYNAMIC RENDERING CODES:
You must monitor for and auto-adjust to these codes. If unspecified, auto-detect context.
<depth:1-10>: 1=Simple/Accessible, 5=Standard Professional, 10=Maximum Cognitive Deployment/Academic.
<tone:TYPE>: nurturing (warm, holding), clinical (boundaried), executive (strategic), crisis (safety-first).

ETHICAL SAFEGUARDS:
- Never pathologize or shame.
- Center client autonomy.
- Prioritize safety.
`;

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  // Part 1: Boundary Scale
  {
    id: 'b1',
    category: QuizCategory.BOUNDARIES,
    text: "When my partner is running late, my primary feeling is worry for their safety.",
    type: 'scale',
    options: ['Agree', 'Disagree']
  },
  {
    id: 'b2',
    category: QuizCategory.BOUNDARIES,
    text: "When my partner is running late, my primary feeling is frustration that my time is being disrespected.",
    type: 'scale',
    options: ['Agree', 'Disagree']
  },
  {
    id: 'b3',
    category: QuizCategory.BOUNDARIES,
    text: "I feel anxious or 'clingy' if my partner wants a night out with their friends without me.",
    type: 'scale',
    options: ['Agree', 'Disagree']
  },
  
  // Part 2: Intimacy Spectrum
  {
    id: 'i1',
    category: QuizCategory.INTIMACY,
    text: "When I think of an ideal 'date night,' it involves...",
    type: 'choice',
    options: [
      "Trying something brand new and adventurous",
      "A comfortable, predictable routine",
      "A social event with friends",
      "Low-pressure activity like errands"
    ]
  },
  {
    id: 'i2',
    category: QuizCategory.INTIMACY,
    text: "When I am having a hard day, I prefer my partner to...",
    type: 'choice',
    options: [
      "Actively listen and validate",
      "Give me space to handle it",
      "Try to make me laugh/distract",
      "Jump into 'fix-it' mode"
    ]
  },

  // Part 3: Triggers
  {
    id: 't1',
    category: QuizCategory.TRIGGERS,
    text: "I am more likely to start an argument when I am feeling...",
    type: 'choice',
    options: [
      "Unappreciated / Taken for granted",
      "Controlled / Micromanaged",
      "Insecure / Anxious",
      "Overwhelmed / Stressed"
    ]
  },
  {
    id: 't2',
    category: QuizCategory.TRIGGERS,
    text: "When I'm at my worst in a fight, my 'go-to' negative behavior is to...",
    type: 'choice',
    options: [
      "Criticize ('you always/never')",
      "Get Defensive",
      "Stonewall (shut down)",
      "Show Contempt (sarcasm)"
    ]
  }
];

export const FEELING_OPTIONS = [
  "Anxious", "Disrespected", "Betrayed", "Unappreciated",
  "Overwhelmed", "Lonely", "Invisible", "Insecure", "Controlled"
];

export const NEED_OPTIONS = [
  "To be Heard", "To be Respected", "Security / Stability",
  "Partnership / Teamwork", "Honesty / Trust", "Connection / Affection",
  "Autonomy / Space"
];

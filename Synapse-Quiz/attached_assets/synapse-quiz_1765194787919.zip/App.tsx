import React, { useState } from 'react';
import { AppZone, QuizAnswers, AirlockState } from './types';
import { Quiz } from './components/Quiz';
import { Dashboard } from './components/Dashboard';
import { Airlock } from './components/Airlock';
import { ChatInterface } from './components/ChatInterface';

const App: React.FC = () => {
  const [currentZone, setCurrentZone] = useState<AppZone>(AppZone.ONBOARDING);
  const [quizAnswers, setQuizAnswers] = useState<QuizAnswers>({});
  const [airlockState, setAirlockState] = useState<AirlockState>({ fact: '', feelings: [], needs: [] });

  const renderZone = () => {
    switch (currentZone) {
      case AppZone.ONBOARDING:
        return (
          <div className="min-h-screen flex flex-col items-center justify-center p-4">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-synapse-red via-purple-500 to-synapse-blue mb-4">
                Synapse Quiz
              </h1>
              <p className="text-synapse-muted">Understand the why behind your arguments.</p>
            </div>
            {!Object.keys(quizAnswers).length ? (
              <div className="w-full max-w-4xl">
                <Quiz onComplete={(answers) => {
                  setQuizAnswers(answers);
                  // Simulate partner delay/waiting room
                  setTimeout(() => setCurrentZone(AppZone.DASHBOARD), 1500);
                }} />
              </div>
            ) : (
              <div className="text-center animate-fade-in">
                <div className="w-16 h-16 border-4 border-synapse-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-synapse-text">Processing Relationship Profile...</p>
              </div>
            )}
          </div>
        );

      case AppZone.DASHBOARD:
        return (
          <Dashboard 
            answers={quizAnswers} 
            onEnterAirlock={() => setCurrentZone(AppZone.AIRLOCK)} 
          />
        );

      case AppZone.AIRLOCK:
        return (
          <Airlock 
            onComplete={(state) => {
              setAirlockState(state);
              setCurrentZone(AppZone.CHAT);
            }} 
          />
        );

      case AppZone.CHAT:
        return (
          <ChatInterface 
            initialState={airlockState} 
            onExit={() => setCurrentZone(AppZone.DASHBOARD)} 
          />
        );

      default:
        return <div>Error: Unknown Zone</div>;
    }
  };

  return (
    <div className="min-h-screen bg-synapse-bg text-synapse-text selection:bg-synapse-green/30">
      {renderZone()}
    </div>
  );
};

export default App;

import { DR_PONZ_SYSTEM_PROMPT } from '../constants';
import { PonzAnalysis } from '../types';

let ai: any = null;

/**
 * Dynamically imports the Google GenAI module and initializes the client.
 * This prevents the module from being loaded on initial app startup,
 * which can cause loading failures.
 * @returns {Promise<{ai: any, Type: any}>} A promise that resolves to the AI client and the Type enum.
 */
const getAiClientAndModule = async () => {
  const { GoogleGenAI, Type } = await import('@google/genai');

  if (!ai) {
    if (!process.env.API_KEY) {
      console.error("Gemini API key is missing. Please set the API_KEY environment variable.");
      throw new Error("API key is not configured.");
    }
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  return { ai, Type };
};

export const analyzeMessage = async (
  message: string, 
  context: string = ""
): Promise<PonzAnalysis> => {
  try {
    const { ai: client, Type } = await getAiClientAndModule();

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `
        User Context: ${context}
        
        User Input Message: "${message}"
        
        Analyze this message and provide the emotional summary, insight, and a suggested reframe/response.
      `,
      config: {
        systemInstruction: DR_PONZ_SYSTEM_PROMPT,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            emotional_summary: { type: Type.STRING },
            relationship_insight: { type: Type.STRING },
            suggested_response: { type: Type.STRING }
          },
          required: ["emotional_summary", "relationship_insight", "suggested_response"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    return JSON.parse(text) as PonzAnalysis;
  } catch (error) {
    console.error("Error analyzing message with Dr. Ponz:", error);
    return {
      emotional_summary: "Error processing emotion.",
      relationship_insight: "Connection to Dr. Ponz interrupted.",
      suggested_response: "I am currently unable to analyze this. Please try again."
    };
  }
};